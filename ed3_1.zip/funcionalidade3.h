#ifndef FUNCIONALIDADE3_H_INCLUDED
#define FUNCIONALIDADE3_H_INCLUDED

int buscaRegistro(FILE* fileP, FILE* fileI, char *nomeDoCampo, int idOpcional);
int checaIntegridadeP(FILE* fileP);
int checaIntegridadeI(FILE *fileI);

#endif // FUNCIONALIDADE3_H_INCLUDED
