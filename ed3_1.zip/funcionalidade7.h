#ifndef FUNCIONALIDADE7_H_INCLUDED
#define FUNCIONALIDADE7_H_INCLUDED

int leBinarioSegue(char* nomeArquivoSegue, char* nomeArquivoSegueOrdenado);

#endif // FUNCIONALIDADE7_H_INCLUDED
