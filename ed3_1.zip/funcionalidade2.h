/*

#ifndef FUNCIONALIDADE2_H_INCLUDED
#define FUNCIONALIDADE2_H_INCLUDED

#include "LDED.h"

void printaFormatado(dadoPessoa pessoa);
void printaFormatado(dadoPessoa pessoa);


#endif // FUNCIONALIDADE2_H_INCLUDED
*/
