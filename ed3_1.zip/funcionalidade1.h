/*
#ifndef FUNCIONALIDADE1_H_INCLUDED
#define FUNCIONALIDADE1_H_INCLUDED

#include "LDED.h"

int inicializaCabecalhoPessoa(FILE *fileP, cabecalhoArqPessoa *cp);
int atualizaCabecalhoPessoa(FILE *fileP, cabecalhoArqPessoa cp);
void insereBinario(FILE *fileP, cabecalhoArqPessoa *cp, Lista* li, dadoPessoa pessoa);
int montaIndex(char *nomeArqIndex, Lista* li);





#endif // FUNCIONALIDADE1_H_INCLUDED

*/
