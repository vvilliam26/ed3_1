#ifndef FUNCIONALIDADE12_H_INCLUDED
#define FUNCIONALIDADE12_H_INCLUDED

#include "graph.h"

int dfs(Graph* G, char *nome);


#endif // FUNCIONALIDADE12_H_INCLUDED
